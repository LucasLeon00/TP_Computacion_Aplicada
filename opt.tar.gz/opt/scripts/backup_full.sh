#!/bin/bash

# Mostrar ayuda si se pasa -help como argumento
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 [origen] [destino]"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Este script realiza un backup completo del directorio de origen,"
    echo "y lo guarda en el destino con un nombre que incluye la fecha (formato YYYYMMDD)."
    exit 0

# Validar que se pasen exactamente dos argumentos
elif [ "$#" -ne 2 ]; then
    echo "Error: se requieren dos argumentos: [origen] [destino]."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

# Validar que el directorio de origen existe
if [ ! -d "$1" ]; then
    echo "Error: el directorio de origen '$1' no existe o no está disponible."
    exit 1

# Validar que el directorio de destino existe
elif [ ! -d "$2" ]; then
    echo "Error: el directorio de destino '$2' no existe o no está disponible."
    exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup, basado en el nombre base del directorio origen
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

# Verificar si el archivo de backup se creó correctamente
if [ -f "$2/$BACKUP" ]; then
    echo "Backup creado exitosamente: $2/$BACKUP"
else
    echo "Error: el backup no se pudo crear."
    exit 1
fi

